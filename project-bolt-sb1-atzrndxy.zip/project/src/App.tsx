import React, { useState } from 'react';
import Sidebar from './components/Layout/Sidebar';
import Layout from './components/Layout/Layout';
import Dashboard from './pages/Dashboard';
import IdealGasLaw from './pages/IdealGasLaw';
import HeatEquation from './pages/HeatEquation';
import CarnotEfficiency from './pages/CarnotEfficiency';
import PVTSDiagrams from './pages/PVTSDiagrams';

function App() {
  const [currentPage, setCurrentPage] = useState('dashboard');

  const renderPage = () => {
    switch (currentPage) {
      case 'dashboard':
        return <Dashboard onPageChange={setCurrentPage} />;
      case 'ideal-gas':
        return <IdealGasLaw />;
      case 'heat-equation':
        return <HeatEquation />;
      case 'carnot':
        return <CarnotEfficiency />;
      case 'diagrams':
        return <PVTSDiagrams />;
      default:
        return <Dashboard onPageChange={setCurrentPage} />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100">
      <Sidebar currentPage={currentPage} onPageChange={setCurrentPage} />
      <Layout>
        {renderPage()}
      </Layout>
    </div>
  );
}

export default App;