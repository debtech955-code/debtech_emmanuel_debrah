import React from 'react';
import { Calculator, Home, Thermometer, Zap, TrendingUp, Activity } from 'lucide-react';

interface SidebarProps {
  currentPage: string;
  onPageChange: (page: string) => void;
}

const navigation = [
  { name: 'Dashboard', page: 'dashboard', icon: Home },
  { name: 'Ideal Gas Law', page: 'ideal-gas', icon: Calculator },
  { name: 'Heat Equation', page: 'heat-equation', icon: Thermometer },
  { name: 'Carnot Efficiency', page: 'carnot', icon: Zap },
  { name: 'PV/TS Diagrams', page: 'diagrams', icon: TrendingUp },
];

export default function Sidebar({ currentPage, onPageChange }: SidebarProps) {
  return (
    <div className="fixed inset-y-0 left-0 z-50 w-64 bg-gradient-to-b from-slate-900 via-slate-800 to-slate-900 shadow-2xl">
      <div className="flex h-full flex-col">
        {/* Logo */}
        <div className="flex h-16 shrink-0 items-center px-6 border-b border-slate-700/50">
          <Activity className="h-8 w-8 text-blue-400" />
          <span className="ml-3 text-xl font-bold text-white">ThermoCalc</span>
        </div>

        {/* Navigation */}
        <nav className="flex-1 px-4 py-6 space-y-2">
          {navigation.map((item) => {
            const Icon = item.icon;
            const isActive = currentPage === item.page;
            
            return (
              <button
                key={item.name}
                onClick={() => onPageChange(item.page)}
                className={`w-full flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-all duration-200 ${
                  isActive
                    ? 'bg-gradient-to-r from-blue-600 to-blue-500 text-white shadow-lg shadow-blue-500/25'
                    : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
                }`}
              >
                <Icon className="mr-3 h-5 w-5" />
                {item.name}
              </button>
            );
          })}
        </nav>

        {/* Footer */}
        <div className="px-4 py-6 border-t border-slate-700/50">
          <p className="text-xs text-slate-400 text-center">
            Advanced Thermodynamic<br />Calculator Suite
          </p>
        </div>
      </div>
    </div>
  );
}