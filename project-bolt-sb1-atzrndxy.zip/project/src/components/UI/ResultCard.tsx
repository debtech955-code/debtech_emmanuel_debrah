import React from 'react';
import Card from './Card';

interface ResultCardProps {
  title: string;
  value: number | string;
  unit?: string;
  description?: string;
}

export default function ResultCard({ title, value, unit, description }: ResultCardProps) {
  return (
    <Card className="p-6">
      <div className="text-center">
        <h3 className="text-lg font-semibold text-slate-700 mb-2">{title}</h3>
        <div className="text-3xl font-bold text-blue-600 mb-2">
          {typeof value === 'number' ? value.toLocaleString(undefined, { maximumFractionDigits: 4 }) : value}
          {unit && <span className="text-xl text-slate-500 ml-2">{unit}</span>}
        </div>
        {description && (
          <p className="text-sm text-slate-600">{description}</p>
        )}
      </div>
    </Card>
  );
}