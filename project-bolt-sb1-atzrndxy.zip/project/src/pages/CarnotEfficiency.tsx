import React, { useState } from 'react';
import Card from '../components/UI/Card';
import Input from '../components/UI/Input';
import Select from '../components/UI/Select';
import Button from '../components/UI/Button';
import ResultCard from '../components/UI/ResultCard';
import { calculateCarnotEfficiency } from '../utils/calculations';
import { CarnotInputs } from '../types';

const temperatureUnits = [
  { value: 'K', label: 'Kelvin (K)' },
  { value: '°C', label: 'Celsius (°C)' },
  { value: '°F', label: 'Fahrenheit (°F)' }
];

export default function CarnotEfficiency() {
  const [inputs, setInputs] = useState<CarnotInputs>({
    hotTemperature: 500,
    coldTemperature: 300,
    temperatureUnit: 'K'
  });
  const [efficiency, setEfficiency] = useState<number | null>(null);
  const [error, setError] = useState('');

  const updateInput = (field: keyof CarnotInputs, value: string | number) => {
    setInputs(prev => ({ ...prev, [field]: value }));
    setError('');
  };

  const handleCalculate = () => {
    if (!inputs.hotTemperature || !inputs.coldTemperature) {
      setError('Please provide both hot and cold reservoir temperatures');
      return;
    }

    const calculatedEfficiency = calculateCarnotEfficiency(inputs);
    if (calculatedEfficiency !== null) {
      setEfficiency(calculatedEfficiency);
      setError('');
    } else {
      setError('Invalid temperatures. Ensure Th > Tc > 0 and both temperatures are in absolute scale');
      setEfficiency(null);
    }
  };

  return (
    <div className="max-w-6xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-slate-800 mb-4">Carnot Efficiency Calculator</h1>
        <p className="text-slate-600 text-lg">
          Calculate the maximum theoretical efficiency of a heat engine: <strong>η = 1 - (T<sub>c</sub>/T<sub>h</sub>)</strong>
        </p>
        <p className="text-sm text-slate-500 mt-2">
          The Carnot efficiency represents the upper limit of efficiency for any heat engine
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <Card className="p-6">
          <h2 className="text-xl font-semibold text-slate-800 mb-6">Temperature Inputs</h2>
          
          <div className="space-y-6">
            <Select
              label="Temperature Unit"
              value={inputs.temperatureUnit}
              onChange={(value) => updateInput('temperatureUnit', value)}
              options={temperatureUnits}
              required
            />

            <Input
              label="Hot Reservoir Temperature (Th)"
              value={inputs.hotTemperature.toString()}
              onChange={(value) => updateInput('hotTemperature', parseFloat(value) || 0)}
              type="number"
              placeholder="500"
              required
            />

            <Input
              label="Cold Reservoir Temperature (Tc)"
              value={inputs.coldTemperature.toString()}
              onChange={(value) => updateInput('coldTemperature', parseFloat(value) || 0)}
              type="number"
              placeholder="300"
              required
            />

            {error && (
              <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                <p className="text-red-600">{error}</p>
              </div>
            )}

            <Button onClick={handleCalculate} className="w-full">
              Calculate Carnot Efficiency
            </Button>
          </div>
        </Card>

        <div className="space-y-6">
          {efficiency !== null && (
            <>
              <ResultCard
                title="Carnot Efficiency"
                value={(efficiency * 100).toFixed(2)}
                unit="%"
                description="Maximum theoretical efficiency for this temperature difference"
              />
              
              <ResultCard
                title="Efficiency (Decimal)"
                value={efficiency.toFixed(4)}
                description="Efficiency as a decimal fraction"
              />

              <Card className="p-6">
                <h3 className="text-lg font-semibold text-slate-800 mb-4">Performance Analysis</h3>
                <div className="space-y-3 text-sm text-slate-600">
                  <div className="flex justify-between">
                    <span>Temperature Ratio (Tc/Th):</span>
                    <span className="font-mono">{(inputs.coldTemperature / inputs.hotTemperature).toFixed(4)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Waste Heat Fraction:</span>
                    <span className="font-mono">{((1 - efficiency) * 100).toFixed(2)}%</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Work Output per Heat Input:</span>
                    <span className="font-mono">{efficiency.toFixed(4)} J/J</span>
                  </div>
                </div>
              </Card>
            </>
          )}

          <Card className="p-6">
            <h3 className="text-lg font-semibold text-slate-800 mb-4">About Carnot Efficiency</h3>
            <div className="space-y-3 text-sm text-slate-600">
              <p>
                The Carnot efficiency represents the theoretical maximum efficiency of any heat engine 
                operating between two thermal reservoirs:
              </p>
              <p className="text-center font-mono text-lg text-green-600 bg-green-50 p-3 rounded">
                η = 1 - (T<sub>c</sub>/T<sub>h</sub>)
              </p>
              <ul className="space-y-2">
                <li><strong>η</strong> = Efficiency (0 to 1)</li>
                <li><strong>T<sub>h</sub></strong> = Temperature of hot reservoir (K)</li>
                <li><strong>T<sub>c</sub></strong> = Temperature of cold reservoir (K)</li>
              </ul>
              <div className="bg-yellow-50 p-3 rounded mt-4">
                <h4 className="font-semibold text-yellow-800 mb-2">Key Points:</h4>
                <ul className="text-xs space-y-1">
                  <li>• Temperatures must be in absolute scale (Kelvin)</li>
                  <li>• Real engines always have lower efficiency than Carnot</li>
                  <li>• Efficiency increases with larger temperature difference</li>
                  <li>• 100% efficiency is only possible at absolute zero</li>
                </ul>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}