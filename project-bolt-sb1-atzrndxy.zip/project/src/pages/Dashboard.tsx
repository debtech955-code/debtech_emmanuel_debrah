import React from 'react';
import Card from '../components/UI/Card';
import { Calculator, Thermometer, Zap, TrendingUp } from 'lucide-react';

interface DashboardProps {
  onPageChange: (page: string) => void;
}

const calculators = [
  {
    title: 'Ideal Gas Law',
    description: 'Calculate pressure, volume, temperature, or amount using PV = nRT',
    icon: Calculator,
    page: 'ideal-gas',
    color: 'from-blue-500 to-cyan-400'
  },
  {
    title: 'Heat Equation',
    description: 'Determine heat transfer using Q = mcΔT',
    icon: Thermometer,
    page: 'heat-equation',
    color: 'from-red-500 to-orange-400'
  },
  {
    title: 'Carnot Efficiency',
    description: 'Calculate maximum theoretical efficiency of heat engines',
    icon: Zap,
    page: 'carnot',
    color: 'from-green-500 to-emerald-400'
  },
  {
    title: 'PV/TS Diagrams',
    description: 'Visualize thermodynamic processes on interactive diagrams',
    icon: TrendingUp,
    page: 'diagrams',
    color: 'from-purple-500 to-pink-400'
  }
];

export default function Dashboard({ onPageChange }: DashboardProps) {
  return (
    <div className="max-w-7xl mx-auto">
      {/* Header */}
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-slate-800 mb-4">
          Advanced Thermodynamics Calculator
        </h1>
        <p className="text-xl text-slate-600 max-w-3xl mx-auto">
          Comprehensive suite of thermodynamic calculators and visualization tools 
          for engineering, physics, and chemistry applications
        </p>
      </div>

      {/* Calculator Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
        {calculators.map((calc) => {
          const Icon = calc.icon;
          return (
            <Card 
              key={calc.page} 
              onClick={() => onPageChange(calc.page)}
              className="p-8 group"
            >
              <div className="flex items-start space-x-4">
                <div className={`p-3 rounded-lg bg-gradient-to-r ${calc.color} shadow-lg group-hover:shadow-xl transition-all duration-200`}>
                  <Icon className="h-6 w-6 text-white" />
                </div>
                <div className="flex-1">
                  <h3 className="text-xl font-semibold text-slate-800 mb-2 group-hover:text-blue-600 transition-colors">
                    {calc.title}
                  </h3>
                  <p className="text-slate-600 leading-relaxed">
                    {calc.description}
                  </p>
                </div>
              </div>
            </Card>
          );
        })}
      </div>

      {/* Features Section */}
      <Card className="p-8">
        <h2 className="text-2xl font-semibold text-slate-800 mb-6 text-center">
          Key Features
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="text-center">
            <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-cyan-400 rounded-lg flex items-center justify-center mx-auto mb-4">
              <Calculator className="h-6 w-6 text-white" />
            </div>
            <h3 className="font-semibold text-slate-800 mb-2">Precise Calculations</h3>
            <p className="text-slate-600 text-sm">
              Industry-standard formulas with comprehensive unit conversions
            </p>
          </div>
          <div className="text-center">
            <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-pink-400 rounded-lg flex items-center justify-center mx-auto mb-4">
              <TrendingUp className="h-6 w-6 text-white" />
            </div>
            <h3 className="font-semibold text-slate-800 mb-2">Interactive Diagrams</h3>
            <p className="text-slate-600 text-sm">
              Dynamic PV and TS diagrams for process visualization
            </p>
          </div>
          <div className="text-center">
            <div className="w-12 h-12 bg-gradient-to-r from-green-500 to-emerald-400 rounded-lg flex items-center justify-center mx-auto mb-4">
              <Thermometer className="h-6 w-6 text-white" />
            </div>
            <h3 className="font-semibold text-slate-800 mb-2">Multiple Units</h3>
            <p className="text-slate-600 text-sm">
              Support for SI, Imperial, and specialized engineering units
            </p>
          </div>
        </div>
      </Card>
    </div>
  );
}