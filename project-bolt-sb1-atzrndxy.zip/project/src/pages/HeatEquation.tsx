import React, { useState } from 'react';
import Card from '../components/UI/Card';
import Input from '../components/UI/Input';
import Select from '../components/UI/Select';
import Button from '../components/UI/Button';
import ResultCard from '../components/UI/ResultCard';
import { calculateHeatEquation } from '../utils/calculations';
import { HeatEquationInputs, CalculationResult } from '../types';

const energyUnits = [
  { value: 'J', label: 'Joule (J)' },
  { value: 'kJ', label: 'Kilojoule (kJ)' },
  { value: 'cal', label: 'Calorie (cal)' },
  { value: 'kcal', label: 'Kilocalorie (kcal)' },
  { value: 'BTU', label: 'British Thermal Unit (BTU)' }
];

const massUnits = [
  { value: 'kg', label: 'Kilogram (kg)' },
  { value: 'g', label: 'Gram (g)' },
  { value: 'lb', label: 'Pound (lb)' }
];

const specificHeatUnits = [
  { value: 'J/kg·K', label: 'J/(kg·K)' },
  { value: 'kJ/kg·K', label: 'kJ/(kg·K)' },
  { value: 'cal/g·°C', label: 'cal/(g·°C)' },
  { value: 'BTU/lb·°F', label: 'BTU/(lb·°F)' }
];

const temperatureUnits = [
  { value: 'K', label: 'Kelvin (K)' },
  { value: '°C', label: 'Celsius (°C)' },
  { value: '°F', label: 'Fahrenheit (°F)' }
];

const variables = [
  { value: 'Q', label: 'Heat Energy (Q)' },
  { value: 'm', label: 'Mass (m)' },
  { value: 'c', label: 'Specific Heat (c)' },
  { value: 'deltaT', label: 'Temperature Change (ΔT)' }
];

export default function HeatEquation() {
  const [missingVariable, setMissingVariable] = useState('Q');
  const [inputs, setInputs] = useState<HeatEquationInputs>({
    heatUnit: 'kJ',
    massUnit: 'kg',
    specificHeatUnit: 'J/kg·K',
    temperatureUnit: 'K'
  });
  const [result, setResult] = useState<CalculationResult | null>(null);
  const [error, setError] = useState('');

  const updateInput = (field: keyof HeatEquationInputs, value: string | number) => {
    setInputs(prev => ({ ...prev, [field]: value }));
    setError('');
  };

  const handleCalculate = () => {
    const calculationResult = calculateHeatEquation(inputs, missingVariable);
    if (calculationResult) {
      setResult(calculationResult);
      setError('');
    } else {
      setError('Please provide valid values for all required fields');
      setResult(null);
    }
  };

  const isFieldDisabled = (field: string) => field === missingVariable;

  return (
    <div className="max-w-6xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-slate-800 mb-4">Heat Equation Calculator</h1>
        <p className="text-slate-600 text-lg">
          Calculate heat transfer using the equation: <strong>Q = mcΔT</strong>
        </p>
        <p className="text-sm text-slate-500 mt-2">
          Determine heat energy, mass, specific heat capacity, or temperature change
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <Card className="p-6">
          <h2 className="text-xl font-semibold text-slate-800 mb-6">Input Parameters</h2>
          
          <div className="space-y-6">
            <Select
              label="Calculate missing variable"
              value={missingVariable}
              onChange={setMissingVariable}
              options={variables}
              required
            />

            <div className="grid grid-cols-2 gap-4">
              <Input
                label="Heat Energy (Q)"
                value={isFieldDisabled('Q') ? '' : (inputs.heat?.toString() || '')}
                onChange={(value) => updateInput('heat', parseFloat(value) || undefined)}
                type="number"
                placeholder={isFieldDisabled('Q') ? 'To calculate' : '1000'}
                disabled={isFieldDisabled('Q')}
              />
              <Select
                label="Energy Unit"
                value={inputs.heatUnit}
                onChange={(value) => updateInput('heatUnit', value)}
                options={energyUnits}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <Input
                label="Mass (m)"
                value={isFieldDisabled('m') ? '' : (inputs.mass?.toString() || '')}
                onChange={(value) => updateInput('mass', parseFloat(value) || undefined)}
                type="number"
                placeholder={isFieldDisabled('m') ? 'To calculate' : '1.0'}
                disabled={isFieldDisabled('m')}
              />
              <Select
                label="Mass Unit"
                value={inputs.massUnit}
                onChange={(value) => updateInput('massUnit', value)}
                options={massUnits}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <Input
                label="Specific Heat Capacity (c)"
                value={isFieldDisabled('c') ? '' : (inputs.specificHeat?.toString() || '')}
                onChange={(value) => updateInput('specificHeat', parseFloat(value) || undefined)}
                type="number"
                placeholder={isFieldDisabled('c') ? 'To calculate' : '4186'}
                disabled={isFieldDisabled('c')}
              />
              <Select
                label="Specific Heat Unit"
                value={inputs.specificHeatUnit}
                onChange={(value) => updateInput('specificHeatUnit', value)}
                options={specificHeatUnits}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <Input
                label="Temperature Change (ΔT)"
                value={isFieldDisabled('deltaT') ? '' : (inputs.temperatureChange?.toString() || '')}
                onChange={(value) => updateInput('temperatureChange', parseFloat(value) || undefined)}
                type="number"
                placeholder={isFieldDisabled('deltaT') ? 'To calculate' : '10'}
                disabled={isFieldDisabled('deltaT')}
              />
              <Select
                label="Temperature Unit"
                value={inputs.temperatureUnit}
                onChange={(value) => updateInput('temperatureUnit', value)}
                options={temperatureUnits}
              />
            </div>

            {error && (
              <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                <p className="text-red-600">{error}</p>
              </div>
            )}

            <Button onClick={handleCalculate} className="w-full">
              Calculate {variables.find(v => v.value === missingVariable)?.label}
            </Button>
          </div>
        </Card>

        <div className="space-y-6">
          {result && (
            <ResultCard
              title={result.variable}
              value={result.value}
              unit={result.unit}
              description="Calculated using the heat equation Q = mcΔT"
            />
          )}

          <Card className="p-6">
            <h3 className="text-lg font-semibold text-slate-800 mb-4">About the Heat Equation</h3>
            <div className="space-y-3 text-sm text-slate-600">
              <p>
                The heat equation describes the amount of thermal energy transferred to or from a substance:
              </p>
              <p className="text-center font-mono text-lg text-red-600 bg-red-50 p-3 rounded">
                Q = mcΔT
              </p>
              <ul className="space-y-2">
                <li><strong>Q</strong> = Heat energy transferred (J, cal, BTU)</li>
                <li><strong>m</strong> = Mass of the substance (kg, g, lb)</li>
                <li><strong>c</strong> = Specific heat capacity (J/kg·K, cal/g·°C)</li>
                <li><strong>ΔT</strong> = Temperature change (K, °C, °F)</li>
              </ul>
              <div className="bg-blue-50 p-3 rounded mt-4">
                <h4 className="font-semibold text-blue-800 mb-2">Common Specific Heat Values:</h4>
                <ul className="text-xs space-y-1">
                  <li>Water: 4186 J/(kg·K)</li>
                  <li>Aluminum: 897 J/(kg·K)</li>
                  <li>Copper: 385 J/(kg·K)</li>
                  <li>Iron: 449 J/(kg·K)</li>
                  <li>Air: 1005 J/(kg·K)</li>
                </ul>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}