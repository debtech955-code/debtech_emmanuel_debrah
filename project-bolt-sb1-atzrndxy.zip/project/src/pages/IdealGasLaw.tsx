import React, { useState } from 'react';
import Card from '../components/UI/Card';
import Input from '../components/UI/Input';
import Select from '../components/UI/Select';
import Button from '../components/UI/Button';
import ResultCard from '../components/UI/ResultCard';
import { calculateIdealGas } from '../utils/calculations';
import { IdealGasInputs, CalculationResult } from '../types';

const pressureUnits = [
  { value: 'Pa', label: 'Pascal (Pa)' },
  { value: 'kPa', label: 'Kilopascal (kPa)' },
  { value: 'MPa', label: 'Megapascal (MPa)' },
  { value: 'atm', label: 'Atmosphere (atm)' },
  { value: 'bar', label: 'Bar (bar)' },
  { value: 'psi', label: 'PSI (psi)' }
];

const volumeUnits = [
  { value: 'm³', label: 'Cubic meter (m³)' },
  { value: 'L', label: 'Liter (L)' },
  { value: 'mL', label: 'Milliliter (mL)' },
  { value: 'ft³', label: 'Cubic foot (ft³)' }
];

const temperatureUnits = [
  { value: 'K', label: 'Kelvin (K)' },
  { value: '°C', label: 'Celsius (°C)' },
  { value: '°F', label: 'Fahrenheit (°F)' }
];

const variables = [
  { value: 'P', label: 'Pressure (P)' },
  { value: 'V', label: 'Volume (V)' },
  { value: 'n', label: 'Amount of substance (n)' },
  { value: 'T', label: 'Temperature (T)' }
];

export default function IdealGasLaw() {
  const [missingVariable, setMissingVariable] = useState('P');
  const [inputs, setInputs] = useState<IdealGasInputs>({
    pressureUnit: 'atm',
    volumeUnit: 'L',
    temperatureUnit: 'K'
  });
  const [result, setResult] = useState<CalculationResult | null>(null);
  const [error, setError] = useState('');

  const updateInput = (field: keyof IdealGasInputs, value: string | number) => {
    setInputs(prev => ({ ...prev, [field]: value }));
    setError('');
  };

  const handleCalculate = () => {
    const calculationResult = calculateIdealGas(inputs, missingVariable);
    if (calculationResult) {
      setResult(calculationResult);
      setError('');
    } else {
      setError('Please provide valid values for all required fields');
      setResult(null);
    }
  };

  const isFieldDisabled = (field: string) => field === missingVariable;

  return (
    <div className="max-w-6xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-slate-800 mb-4">Ideal Gas Law Calculator</h1>
        <p className="text-slate-600 text-lg">
          Calculate any variable in the ideal gas equation: <strong>PV = nRT</strong>
        </p>
        <p className="text-sm text-slate-500 mt-2">
          Gas constant R = 8.314 J/(mol·K)
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <Card className="p-6">
          <h2 className="text-xl font-semibold text-slate-800 mb-6">Input Parameters</h2>
          
          <div className="space-y-6">
            <Select
              label="Calculate missing variable"
              value={missingVariable}
              onChange={setMissingVariable}
              options={variables}
              required
            />

            <div className="grid grid-cols-2 gap-4">
              <Input
                label="Pressure"
                value={isFieldDisabled('P') ? '' : (inputs.pressure?.toString() || '')}
                onChange={(value) => updateInput('pressure', parseFloat(value) || undefined)}
                type="number"
                placeholder={isFieldDisabled('P') ? 'To calculate' : '1.0'}
                disabled={isFieldDisabled('P')}
              />
              <Select
                label="Pressure Unit"
                value={inputs.pressureUnit}
                onChange={(value) => updateInput('pressureUnit', value)}
                options={pressureUnits}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <Input
                label="Volume"
                value={isFieldDisabled('V') ? '' : (inputs.volume?.toString() || '')}
                onChange={(value) => updateInput('volume', parseFloat(value) || undefined)}
                type="number"
                placeholder={isFieldDisabled('V') ? 'To calculate' : '22.4'}
                disabled={isFieldDisabled('V')}
              />
              <Select
                label="Volume Unit"
                value={inputs.volumeUnit}
                onChange={(value) => updateInput('volumeUnit', value)}
                options={volumeUnits}
              />
            </div>

            <Input
              label="Amount of substance (n)"
              value={isFieldDisabled('n') ? '' : (inputs.moles?.toString() || '')}
              onChange={(value) => updateInput('moles', parseFloat(value) || undefined)}
              type="number"
              placeholder={isFieldDisabled('n') ? 'To calculate' : '1.0'}
              unit="mol"
              disabled={isFieldDisabled('n')}
            />

            <div className="grid grid-cols-2 gap-4">
              <Input
                label="Temperature"
                value={isFieldDisabled('T') ? '' : (inputs.temperature?.toString() || '')}
                onChange={(value) => updateInput('temperature', parseFloat(value) || undefined)}
                type="number"
                placeholder={isFieldDisabled('T') ? 'To calculate' : '273.15'}
                disabled={isFieldDisabled('T')}
              />
              <Select
                label="Temperature Unit"
                value={inputs.temperatureUnit}
                onChange={(value) => updateInput('temperatureUnit', value)}
                options={temperatureUnits}
              />
            </div>

            {error && (
              <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                <p className="text-red-600">{error}</p>
              </div>
            )}

            <Button onClick={handleCalculate} className="w-full">
              Calculate {variables.find(v => v.value === missingVariable)?.label}
            </Button>
          </div>
        </Card>

        <div className="space-y-6">
          {result && (
            <ResultCard
              title={result.variable}
              value={result.value}
              unit={result.unit}
              description="Calculated using the ideal gas law PV = nRT"
            />
          )}

          <Card className="p-6">
            <h3 className="text-lg font-semibold text-slate-800 mb-4">About the Ideal Gas Law</h3>
            <div className="space-y-3 text-sm text-slate-600">
              <p>
                The ideal gas law combines Boyle's law, Charles's law, and Avogadro's law into a single equation:
              </p>
              <p className="text-center font-mono text-lg text-blue-600 bg-blue-50 p-3 rounded">
                PV = nRT
              </p>
              <ul className="space-y-2">
                <li><strong>P</strong> = Pressure of the gas</li>
                <li><strong>V</strong> = Volume of the gas</li>
                <li><strong>n</strong> = Amount of substance (moles)</li>
                <li><strong>R</strong> = Universal gas constant (8.314 J/mol·K)</li>
                <li><strong>T</strong> = Temperature in Kelvin</li>
              </ul>
              <p className="text-xs text-slate-500 mt-4">
                Note: This law applies to ideal gases under conditions where intermolecular forces 
                and molecular volume are negligible.
              </p>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}