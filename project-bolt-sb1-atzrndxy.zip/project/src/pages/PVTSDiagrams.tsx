import React, { useState } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import Card from '../components/UI/Card';
import Input from '../components/UI/Input';
import Select from '../components/UI/Select';
import Button from '../components/UI/Button';
import { generateProcessData } from '../utils/calculations';

const processTypes = [
  { value: 'isothermal', label: 'Isothermal (T = constant)' },
  { value: 'adiabatic', label: 'Adiabatic (Q = 0)' },
  { value: 'isobaric', label: 'Isobaric (P = constant)' },
  { value: 'isochoric', label: 'Isochoric (V = constant)' }
];

export default function PVTSDiagrams() {
  const [processType, setProcessType] = useState('isothermal');
  const [initialState, setInitialState] = useState({
    pressure: 101325,
    volume: 0.0224,
    temperature: 273.15
  });
  const [data, setData] = useState<any[]>([]);
  const [activeChart, setActiveChart] = useState<'pv' | 'ts'>('pv');

  const handleGenerate = () => {
    const processData = generateProcessData(processType, {
      P: initialState.pressure,
      V: initialState.volume,
      T: initialState.temperature
    });
    setData(processData);
  };

  const formatTooltipValue = (value: number, name: string) => {
    if (name === 'pressure') return [value.toExponential(3) + ' Pa', 'Pressure'];
    if (name === 'volume') return [value.toFixed(6) + ' m³', 'Volume'];
    if (name === 'temperature') return [value.toFixed(2) + ' K', 'Temperature'];
    return [value, name];
  };

  return (
    <div className="max-w-7xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-slate-800 mb-4">PV/TS Diagram Generator</h1>
        <p className="text-slate-600 text-lg">
          Visualize thermodynamic processes on pressure-volume and temperature-entropy diagrams
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Controls */}
        <Card className="p-6">
          <h2 className="text-xl font-semibold text-slate-800 mb-6">Process Parameters</h2>
          
          <div className="space-y-6">
            <Select
              label="Process Type"
              value={processType}
              onChange={setProcessType}
              options={processTypes}
              required
            />

            <div className="space-y-4">
              <h3 className="text-md font-semibold text-slate-700">Initial State</h3>
              
              <Input
                label="Pressure (Pa)"
                value={initialState.pressure.toString()}
                onChange={(value) => setInitialState(prev => ({ ...prev, pressure: parseFloat(value) || 0 }))}
                type="number"
                placeholder="101325"
              />

              <Input
                label="Volume (m³)"
                value={initialState.volume.toString()}
                onChange={(value) => setInitialState(prev => ({ ...prev, volume: parseFloat(value) || 0 }))}
                type="number"
                step="0.0001"
                placeholder="0.0224"
              />

              <Input
                label="Temperature (K)"
                value={initialState.temperature.toString()}
                onChange={(value) => setInitialState(prev => ({ ...prev, temperature: parseFloat(value) || 0 }))}
                type="number"
                placeholder="273.15"
              />
            </div>

            <Button onClick={handleGenerate} className="w-full">
              Generate Diagram
            </Button>

            <div className="flex space-x-2">
              <Button
                variant={activeChart === 'pv' ? 'primary' : 'secondary'}
                onClick={() => setActiveChart('pv')}
                className="flex-1"
              >
                P-V Diagram
              </Button>
              <Button
                variant={activeChart === 'ts' ? 'primary' : 'secondary'}
                onClick={() => setActiveChart('ts')}
                className="flex-1"
              >
                T-S Diagram
              </Button>
            </div>
          </div>
        </Card>

        {/* Chart */}
        <div className="lg:col-span-2">
          <Card className="p-6">
            <h2 className="text-xl font-semibold text-slate-800 mb-6">
              {activeChart === 'pv' ? 'Pressure-Volume' : 'Temperature-Entropy'} Diagram
            </h2>
            
            {data.length > 0 ? (
              <div className="h-96">
                <ResponsiveContainer width="100%" height="100%">
                  {activeChart === 'pv' ? (
                    <LineChart data={data}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                      <XAxis 
                        dataKey="volume" 
                        tickFormatter={(value) => value.toFixed(4)}
                        stroke="#64748b"
                        label={{ value: 'Volume (m³)', position: 'insideBottom', offset: -10 }}
                      />
                      <YAxis 
                        dataKey="pressure"
                        tickFormatter={(value) => value.toExponential(1)}
                        stroke="#64748b"
                        label={{ value: 'Pressure (Pa)', angle: -90, position: 'insideLeft' }}
                      />
                      <Tooltip formatter={formatTooltipValue} />
                      <Legend />
                      <Line 
                        type="monotone" 
                        dataKey="pressure" 
                        stroke="#3b82f6" 
                        strokeWidth={3}
                        dot={{ r: 2 }}
                        name="Process Curve"
                      />
                    </LineChart>
                  ) : (
                    <LineChart data={data}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                      <XAxis 
                        dataKey="temperature" 
                        tickFormatter={(value) => value.toFixed(1)}
                        stroke="#64748b"
                        label={{ value: 'Temperature (K)', position: 'insideBottom', offset: -10 }}
                      />
                      <YAxis 
                        tickFormatter={(value) => value.toFixed(2)}
                        stroke="#64748b"
                        label={{ value: 'Entropy (Relative)', angle: -90, position: 'insideLeft' }}
                      />
                      <Tooltip formatter={formatTooltipValue} />
                      <Legend />
                      <Line 
                        type="monotone" 
                        dataKey="temperature" 
                        stroke="#dc2626" 
                        strokeWidth={3}
                        dot={{ r: 2 }}
                        name="Process Curve"
                      />
                    </LineChart>
                  )}
                </ResponsiveContainer>
              </div>
            ) : (
              <div className="h-96 flex items-center justify-center bg-gray-50 rounded-lg">
                <div className="text-center">
                  <p className="text-gray-600 mb-4">No data to display</p>
                  <p className="text-sm text-gray-500">Generate a diagram using the controls</p>
                </div>
              </div>
            )}
          </Card>

          {/* Process Information */}
          <Card className="p-6 mt-6">
            <h3 className="text-lg font-semibold text-slate-800 mb-4">Process Information</h3>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <h4 className="font-semibold text-slate-700 mb-2">Process Characteristics:</h4>
                <div className="space-y-1 text-slate-600">
                  {processType === 'isothermal' && (
                    <>
                      <p>• Temperature remains constant</p>
                      <p>• PV = constant</p>
                      <p>• Heat transfer occurs</p>
                    </>
                  )}
                  {processType === 'adiabatic' && (
                    <>
                      <p>• No heat transfer (Q = 0)</p>
                      <p>• PV^γ = constant</p>
                      <p>• Temperature changes</p>
                    </>
                  )}
                  {processType === 'isobaric' && (
                    <>
                      <p>• Pressure remains constant</p>
                      <p>• V/T = constant</p>
                      <p>• Work = P × ΔV</p>
                    </>
                  )}
                  {processType === 'isochoric' && (
                    <>
                      <p>• Volume remains constant</p>
                      <p>• P/T = constant</p>
                      <p>• No work done (W = 0)</p>
                    </>
                  )}
                </div>
              </div>
              <div>
                <h4 className="font-semibold text-slate-700 mb-2">Applications:</h4>
                <div className="space-y-1 text-slate-600">
                  {processType === 'isothermal' && (
                    <>
                      <p>• Slow compression/expansion</p>
                      <p>• Heat baths</p>
                      <p>• Boiling/condensation</p>
                    </>
                  )}
                  {processType === 'adiabatic' && (
                    <>
                      <p>• Rapid compression/expansion</p>
                      <p>• Diesel engine compression</p>
                      <p>• Atmospheric processes</p>
                    </>
                  )}
                  {processType === 'isobaric' && (
                    <>
                      <p>• Heating at constant pressure</p>
                      <p>• Piston-cylinder systems</p>
                      <p>• Phase transitions</p>
                    </>
                  )}
                  {processType === 'isochoric' && (
                    <>
                      <p>• Heating in rigid containers</p>
                      <p>• Automotive combustion</p>
                      <p>• Pressure vessel heating</p>
                    </>
                  )}
                </div>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}