export interface CalculationResult {
  value: number;
  unit: string;
  variable: string;
}

export interface IdealGasInputs {
  pressure?: number;
  volume?: number;
  moles?: number;
  temperature?: number;
  pressureUnit: string;
  volumeUnit: string;
  temperatureUnit: string;
}

export interface HeatEquationInputs {
  heat?: number;
  mass?: number;
  specificHeat?: number;
  temperatureChange?: number;
  heatUnit: string;
  massUnit: string;
  specificHeatUnit: string;
  temperatureUnit: string;
}

export interface CarnotInputs {
  hotTemperature: number;
  coldTemperature: number;
  temperatureUnit: string;
}

export interface ProcessPoint {
  pressure: number;
  volume: number;
  temperature: number;
}