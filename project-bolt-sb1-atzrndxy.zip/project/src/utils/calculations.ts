import { IdealGasInputs, HeatEquationInputs, CarnotInputs, CalculationResult } from '../types';

// Unit conversion factors to SI units
const PRESSURE_CONVERSIONS = {
  'Pa': 1,
  'kPa': 1000,
  'MPa': 1000000,
  'atm': 101325,
  'bar': 100000,
  'psi': 6895
};

const VOLUME_CONVERSIONS = {
  'm³': 1,
  'L': 0.001,
  'mL': 0.000001,
  'ft³': 0.0283168
};

const TEMPERATURE_CONVERSIONS = {
  'K': (t: number) => t,
  '°C': (t: number) => t + 273.15,
  '°F': (t: number) => (t - 32) * 5/9 + 273.15
};

const ENERGY_CONVERSIONS = {
  'J': 1,
  'kJ': 1000,
  'cal': 4.184,
  'kcal': 4184,
  'BTU': 1055
};

const MASS_CONVERSIONS = {
  'kg': 1,
  'g': 0.001,
  'lb': 0.453592
};

const SPECIFIC_HEAT_CONVERSIONS = {
  'J/kg·K': 1,
  'kJ/kg·K': 1000,
  'cal/g·°C': 4184,
  'BTU/lb·°F': 4186.8
};

// Ideal Gas Law: PV = nRT (R = 8.314 J/mol·K)
const R = 8.314;

export function calculateIdealGas(inputs: IdealGasInputs, missingVariable: string): CalculationResult | null {
  try {
    // Convert to SI units
    const P = inputs.pressure ? inputs.pressure * PRESSURE_CONVERSIONS[inputs.pressureUnit as keyof typeof PRESSURE_CONVERSIONS] : undefined;
    const V = inputs.volume ? inputs.volume * VOLUME_CONVERSIONS[inputs.volumeUnit as keyof typeof VOLUME_CONVERSIONS] : undefined;
    const n = inputs.moles;
    const T = inputs.temperature ? TEMPERATURE_CONVERSIONS[inputs.temperatureUnit as keyof typeof TEMPERATURE_CONVERSIONS](inputs.temperature) : undefined;

    let result: number;
    let unit: string;

    switch (missingVariable) {
      case 'P':
        if (!V || !n || !T) return null;
        result = (n * R * T) / V;
        unit = inputs.pressureUnit;
        return {
          value: result / PRESSURE_CONVERSIONS[inputs.pressureUnit as keyof typeof PRESSURE_CONVERSIONS],
          unit,
          variable: 'Pressure'
        };
      
      case 'V':
        if (!P || !n || !T) return null;
        result = (n * R * T) / P;
        unit = inputs.volumeUnit;
        return {
          value: result / VOLUME_CONVERSIONS[inputs.volumeUnit as keyof typeof VOLUME_CONVERSIONS],
          unit,
          variable: 'Volume'
        };
      
      case 'n':
        if (!P || !V || !T) return null;
        result = (P * V) / (R * T);
        unit = 'mol';
        return {
          value: result,
          unit,
          variable: 'Amount of substance'
        };
      
      case 'T':
        if (!P || !V || !n) return null;
        result = (P * V) / (n * R);
        unit = inputs.temperatureUnit;
        // Convert back from Kelvin to selected unit
        if (inputs.temperatureUnit === '°C') {
          result = result - 273.15;
        } else if (inputs.temperatureUnit === '°F') {
          result = (result - 273.15) * 9/5 + 32;
        }
        return {
          value: result,
          unit,
          variable: 'Temperature'
        };
      
      default:
        return null;
    }
  } catch (error) {
    return null;
  }
}

// Heat Equation: Q = mcΔT
export function calculateHeatEquation(inputs: HeatEquationInputs, missingVariable: string): CalculationResult | null {
  try {
    // Convert to SI units
    const Q = inputs.heat ? inputs.heat * ENERGY_CONVERSIONS[inputs.heatUnit as keyof typeof ENERGY_CONVERSIONS] : undefined;
    const m = inputs.mass ? inputs.mass * MASS_CONVERSIONS[inputs.massUnit as keyof typeof MASS_CONVERSIONS] : undefined;
    const c = inputs.specificHeat ? inputs.specificHeat * SPECIFIC_HEAT_CONVERSIONS[inputs.specificHeatUnit as keyof typeof SPECIFIC_HEAT_CONVERSIONS] : undefined;
    const deltaT = inputs.temperatureChange;

    let result: number;
    let unit: string;

    switch (missingVariable) {
      case 'Q':
        if (!m || !c || deltaT === undefined) return null;
        result = m * c * deltaT;
        unit = inputs.heatUnit;
        return {
          value: result / ENERGY_CONVERSIONS[inputs.heatUnit as keyof typeof ENERGY_CONVERSIONS],
          unit,
          variable: 'Heat Energy'
        };
      
      case 'm':
        if (!Q || !c || deltaT === undefined || deltaT === 0) return null;
        result = Q / (c * deltaT);
        unit = inputs.massUnit;
        return {
          value: result / MASS_CONVERSIONS[inputs.massUnit as keyof typeof MASS_CONVERSIONS],
          unit,
          variable: 'Mass'
        };
      
      case 'c':
        if (!Q || !m || deltaT === undefined || deltaT === 0) return null;
        result = Q / (m * deltaT);
        unit = inputs.specificHeatUnit;
        return {
          value: result / SPECIFIC_HEAT_CONVERSIONS[inputs.specificHeatUnit as keyof typeof SPECIFIC_HEAT_CONVERSIONS],
          unit,
          variable: 'Specific Heat'
        };
      
      case 'deltaT':
        if (!Q || !m || !c || c === 0) return null;
        result = Q / (m * c);
        unit = inputs.temperatureUnit;
        return {
          value: result,
          unit,
          variable: 'Temperature Change'
        };
      
      default:
        return null;
    }
  } catch (error) {
    return null;
  }
}

// Carnot Efficiency: η = 1 - (Tc/Th)
export function calculateCarnotEfficiency(inputs: CarnotInputs): number | null {
  try {
    // Convert to Kelvin
    const Th = TEMPERATURE_CONVERSIONS[inputs.temperatureUnit as keyof typeof TEMPERATURE_CONVERSIONS](inputs.hotTemperature);
    const Tc = TEMPERATURE_CONVERSIONS[inputs.temperatureUnit as keyof typeof TEMPERATURE_CONVERSIONS](inputs.coldTemperature);

    if (Th <= 0 || Tc <= 0 || Tc >= Th) return null;

    return 1 - (Tc / Th);
  } catch (error) {
    return null;
  }
}

// Generate process data for PV and TS diagrams
export function generateProcessData(processType: string, initialState: { P: number; V: number; T: number }) {
  const points = [];
  const { P: P1, V: V1, T: T1 } = initialState;

  switch (processType) {
    case 'isothermal':
      // PV = constant
      const PV_constant = P1 * V1;
      for (let i = 0; i <= 20; i++) {
        const V = V1 * (0.5 + i * 0.075); // Volume from 0.5*V1 to 2*V1
        const P = PV_constant / V;
        points.push({ volume: V, pressure: P, temperature: T1 });
      }
      break;

    case 'adiabatic':
      // PV^γ = constant (γ = 1.4 for ideal diatomic gas)
      const gamma = 1.4;
      const PV_gamma_constant = P1 * Math.pow(V1, gamma);
      for (let i = 0; i <= 20; i++) {
        const V = V1 * (0.5 + i * 0.075);
        const P = PV_gamma_constant / Math.pow(V, gamma);
        const T = (P * V) / (8.314 * 1); // Assuming n = 1 mol
        points.push({ volume: V, pressure: P, temperature: T });
      }
      break;

    case 'isobaric':
      // P = constant
      for (let i = 0; i <= 20; i++) {
        const T = T1 * (0.5 + i * 0.075); // Temperature variation
        const V = (8.314 * 1 * T) / P1; // V = nRT/P
        points.push({ volume: V, pressure: P1, temperature: T });
      }
      break;

    case 'isochoric':
      // V = constant
      for (let i = 0; i <= 20; i++) {
        const T = T1 * (0.5 + i * 0.075);
        const P = (8.314 * 1 * T) / V1; // P = nRT/V
        points.push({ volume: V1, pressure: P, temperature: T });
      }
      break;

    default:
      return [];
  }

  return points;
}